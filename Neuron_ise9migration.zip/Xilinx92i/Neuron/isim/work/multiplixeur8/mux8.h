////////////////////////////////////////////////////////////////////////////////
//   ____  ____   
//  /   /\/   /  
// /___/  \  /   
// \   \   \/  
//  \   \        Copyright (c) 2003-2004 Xilinx, Inc.
//  /   /        All Right Reserved. 
// /---/   /\     
// \   \  /  \  
//  \___\/\___\
////////////////////////////////////////////////////////////////////////////////

#ifndef H_Work_multiplixeur8_mux8_H
#define H_Work_multiplixeur8_mux8_H
#ifdef __MINGW32__
#include "xsimMinGW.h"
#else
#include "xsim.h"
#endif


class Work_multiplixeur8_mux8: public HSim__s6 {
public:

    HSim__s1 SE[10];

  char t0;
HSimConstraints *c1;
  char t2;
HSimConstraints *c3;
  char t4;
HSimConstraints *c5;
  char t6;
HSimConstraints *c7;
  char t8;
HSimConstraints *c9;
  char t10;
HSimConstraints *c11;
  char t12;
HSimConstraints *c13;
  char t14;
HSimConstraints *c15;
    Work_multiplixeur8_mux8(const char * name);
    ~Work_multiplixeur8_mux8();
    void constructObject();
    void constructPorts();
    void reset();
    void architectureInstantiate(HSimConfigDecl* cfg);
    virtual void vhdlArchImplement();
};



HSim__s6 *createWork_multiplixeur8_mux8(const char *name);

#endif
