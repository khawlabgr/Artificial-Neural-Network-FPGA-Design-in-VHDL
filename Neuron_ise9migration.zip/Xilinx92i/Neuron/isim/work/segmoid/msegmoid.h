////////////////////////////////////////////////////////////////////////////////
//   ____  ____   
//  /   /\/   /  
// /___/  \  /   
// \   \   \/  
//  \   \        Copyright (c) 2003-2004 Xilinx, Inc.
//  /   /        All Right Reserved. 
// /---/   /\     
// \   \  /  \  
//  \___\/\___\
////////////////////////////////////////////////////////////////////////////////

#ifndef H_Work_segmoid_msegmoid_H
#define H_Work_segmoid_msegmoid_H
#ifdef __MINGW32__
#include "xsimMinGW.h"
#else
#include "xsim.h"
#endif


class Work_segmoid_msegmoid: public HSim__s6 {
public:

    HSim__s1 SE[2];

  HSimArrayType Rombase;
  HSimArrayType Rom;
  char *t0;
    HSim__s1 SA[1];
  int t1;
  char *t2;
    Work_segmoid_msegmoid(const char * name);
    ~Work_segmoid_msegmoid();
    void constructObject();
    void constructPorts();
    void reset();
    void architectureInstantiate(HSimConfigDecl* cfg);
    virtual void vhdlArchImplement();
};



HSim__s6 *createWork_segmoid_msegmoid(const char *name);

#endif
